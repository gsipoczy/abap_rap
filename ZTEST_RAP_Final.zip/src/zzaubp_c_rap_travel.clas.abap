class ZZAUBP_C_RAP_TRAVEL definition
  public
  abstract
  final
  for behavior of ZZAUC_RAP_TRAVEL .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZZAUBP_C_RAP_TRAVEL IMPLEMENTATION.
ENDCLASS.
