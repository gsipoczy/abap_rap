*"* use this source file for your ABAP unit test classes
CLASS ltc_rap_travel DEFINITION FINAL FOR TESTING
  DURATION SHORT
  RISK LEVEL HARMLESS.

  PRIVATE SECTION.
    CLASS-DATA:
      cds_test_environment TYPE REF TO if_cds_test_environment.

    CLASS-METHODS:
      class_setup,
      class_teardown.

    METHODS:
      setup,
      teardown,
      create_and_accept_travel FOR TESTING RAISING cx_static_check,
      validate_dates_in_past   FOR TESTING RAISING cx_static_check.
ENDCLASS.


CLASS ltc_rap_travel IMPLEMENTATION.

  METHOD class_setup.
    cds_test_environment = cl_cds_test_environment=>create_for_multiple_cds(
      i_for_entities = VALUE #(
        ( i_for_entity = 'ZR_RAP_TRAVEL' )
        ( i_for_entity = 'ZR_RAP_BOOKING' )
      ) ).
  ENDMETHOD.

  METHOD class_teardown.
    cds_test_environment->destroy( ).
  ENDMETHOD.

  METHOD setup.
    cds_test_environment->clear_doubles( ).
  ENDMETHOD.

  METHOD teardown.
    ROLLBACK ENTITIES.
  ENDMETHOD.

  METHOD create_and_accept_travel.
    DATA(lv_begin_date) = cl_abap_context_info=>get_system_date( ) + 10.
    DATA(lv_end_date)   = lv_begin_date + 5.

    " 1. Create a Travel header + 1 child Booking using EML
    MODIFY ENTITIES OF zr_rap_travel
      ENTITY Travel
        CREATE FIELDS ( AgencyID CustomerID BeginDate EndDate BookingFee CurrencyCode Description )
        WITH VALUE #( ( %cid         = 'TRAVEL_1'
                        %is_draft    = if_abap_behv=>mk-off
                        AgencyID     = '070001'
                        CustomerID   = '000001'
                        BeginDate    = lv_begin_date
                        EndDate      = lv_end_date
                        BookingFee   = '50.00'
                        CurrencyCode = 'CHF'
                        Description  = 'Unit Test Trip' ) )
        CREATE BY \_Booking FIELDS ( BookingDate CustomerID CarrierID ConnectionID FlightDate FlightPrice CurrencyCode BookingStatus )
        WITH VALUE #( ( %cid_ref  = 'TRAVEL_1'
                        %is_draft = if_abap_behv=>mk-off
                        %target   = VALUE #( ( %cid          = 'BOOKING_1'
                                               %is_draft     = if_abap_behv=>mk-off
                                               BookingDate   = cl_abap_context_info=>get_system_date( )
                                               CustomerID    = '000001'
                                               CarrierID     = 'LH'
                                               ConnectionID  = '0400'
                                               FlightDate    = lv_begin_date
                                               FlightPrice   = '200.00'
                                               CurrencyCode  = 'CHF'
                                               BookingStatus = 'N' ) ) ) )
      MAPPED DATA(ls_mapped)
      FAILED DATA(ls_failed)
      REPORTED DATA(ls_reported).

    cl_abap_unit_assert=>assert_initial( ls_failed-travel ).
    cl_abap_unit_assert=>assert_initial( ls_failed-booking ).

    " 2. Execute the custom action acceptTravel
    MODIFY ENTITIES OF zr_rap_travel
      ENTITY Travel
        EXECUTE acceptTravel
        FROM VALUE #( ( %tky = ls_mapped-travel[ 1 ]-%tky ) )
      RESULT DATA(lt_action_result)
      FAILED ls_failed
      REPORTED ls_reported.

    cl_abap_unit_assert=>assert_initial( ls_failed-travel ).

    " 3. Persist to the in-memory test double (triggers on-save validations too!)
    COMMIT ENTITIES RESPONSES
      FAILED DATA(ls_commit_failed)
      REPORTED DATA(ls_commit_reported).

    cl_abap_unit_assert=>assert_initial( ls_commit_failed ).

    " 4. Read back and assert TotalPrice (50 + 200 = 250) and OverallStatus ('A')
    READ ENTITIES OF zr_rap_travel
      ENTITY Travel
        FIELDS ( TravelID TotalPrice OverallStatus )
        WITH VALUE #( ( %tky = ls_mapped-travel[ 1 ]-%tky ) )
      RESULT DATA(lt_travels).

    cl_abap_unit_assert=>assert_equals( act = lines( lt_travels )
                                        exp = 1 ).
    cl_abap_unit_assert=>assert_not_initial( lt_travels[ 1 ]-TravelID ).
    cl_abap_unit_assert=>assert_equals( act = lt_travels[ 1 ]-TotalPrice
                                        exp = '250.00' ).
    cl_abap_unit_assert=>assert_equals( act = lt_travels[ 1 ]-OverallStatus
                                        exp = 'A' ).
  ENDMETHOD.

  METHOD validate_dates_in_past.
    DATA(lv_past_date) = cl_abap_context_info=>get_system_date( ) - 5.

    " Create a Travel with BeginDate in the past
    MODIFY ENTITIES OF zr_rap_travel
      ENTITY Travel
        CREATE FIELDS ( AgencyID CustomerID BeginDate EndDate CurrencyCode )
        WITH VALUE #( ( %cid         = 'TRAVEL_BAD'
                        %is_draft    = if_abap_behv=>mk-off
                        AgencyID     = '070001'
                        CustomerID   = '000001'
                        BeginDate    = lv_past_date
                        EndDate      = lv_past_date + 3
                        CurrencyCode = 'CHF' ) )
      MAPPED DATA(ls_mapped)
      FAILED DATA(ls_failed)
      REPORTED DATA(ls_reported).

    " On-save validation runs during COMMIT ENTITIES
    COMMIT ENTITIES RESPONSES
      FAILED DATA(ls_commit_failed)
      REPORTED DATA(ls_commit_reported).

    " Assert that commit FAILED and reported an error
    cl_abap_unit_assert=>assert_not_initial( ls_commit_failed ).
    cl_abap_unit_assert=>assert_not_initial( ls_commit_reported ).
  ENDMETHOD.

ENDCLASS.
