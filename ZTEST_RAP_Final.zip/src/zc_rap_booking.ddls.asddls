@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Booking - Consumption Projection'
@Metadata.allowExtensions: true
define view entity ZC_RAP_Booking
  as projection on ZR_RAP_Booking
{
  key BookingUUID,
      TravelUUID,
      BookingID,
      BookingDate,

      @ObjectModel.text.element: ['CustomerName']
      @Consumption.valueHelpDefinition: [{ entity: { name: '/DMO/I_Customer', element: 'CustomerID' } }]
      CustomerID,
      _Customer.LastName as CustomerName,

      @ObjectModel.text.element: ['CarrierName']
      @Consumption.valueHelpDefinition: [{ entity: { name: '/DMO/I_Carrier', element: 'AirlineID' } }]
      CarrierID,
      _Carrier.Name      as CarrierName,

      @Consumption.valueHelpDefinition: [{ entity: { name: '/DMO/I_Connection', element: 'ConnectionID' },
                                           additionalBinding: [{ localElement: 'CarrierID', element: 'AirlineID' }] }]
      ConnectionID,

      FlightDate,

      @Semantics.amount.currencyCode: 'CurrencyCode'
      FlightPrice,

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Currency', element: 'Currency' } }]
      CurrencyCode,

      BookingStatus,
      LocalLastChangedAt,

      /* Associations */
      _Travel : redirected to parent ZC_RAP_Travel,
      _Customer,
      _Carrier,
      _Connection
}
