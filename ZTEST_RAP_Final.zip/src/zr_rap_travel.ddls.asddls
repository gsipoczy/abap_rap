@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Travel - Root Entity'
define root view entity ZR_RAP_Travel
  as select from zrap_travel
  association [0..1] to /DMO/I_Agency   as _Agency   on $projection.AgencyID     = _Agency.AgencyID
  association [0..1] to /DMO/I_Customer as _Customer on $projection.CustomerID   = _Customer.CustomerID
  association [1..1] to I_Currency      as _Currency on $projection.CurrencyCode = _Currency.Currency
  composition [0..*] of ZR_RAP_Booking as _Booking
{
  key travel_uuid           as TravelUUID,
      travel_id             as TravelID,
      agency_id             as AgencyID,
      customer_id           as CustomerID,
      begin_date            as BeginDate,
      end_date              as EndDate,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      booking_fee           as BookingFee,
      @Semantics.amount.currencyCode: 'CurrencyCode'
      total_price           as TotalPrice,
      currency_code         as CurrencyCode,
      description           as Description,
      overall_status        as OverallStatus,
      @Semantics.user.createdBy: true
      local_created_by      as LocalCreatedBy,
      @Semantics.systemDateTime.createdAt: true
      local_created_at      as LocalCreatedAt,
      @Semantics.user.localInstanceLastChangedBy: true
      local_last_changed_by as LocalLastChangedBy,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,

      /* Associations */
      _Booking,
      _Agency,
      _Customer,
      _Currency
}
