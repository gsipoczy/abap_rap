CLASS lhc_booking DEFINITION INHERITING FROM cl_abap_behavior_handler.

  PRIVATE SECTION.

    METHODS setBookingNumber FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Booking~setBookingNumber.

    METHODS calculateTotalPrice FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Booking~calculateTotalPrice.
    METHODS validateCurrencyCode FOR VALIDATE ON SAVE
      IMPORTING keys FOR Booking~validateCurrencyCode.

ENDCLASS.

CLASS lhc_booking IMPLEMENTATION.

  METHOD setBookingNumber.
    DATA max_bookingid TYPE /dmo/booking_id.
    DATA bookings_update TYPE TABLE FOR UPDATE zr_rap_travel\\Booking.

    " 1. Read the parent Travel records for the newly created Bookings
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Booking BY \_Travel
        FIELDS ( TravelUUID )
        WITH CORRESPONDING #( keys )
      RESULT DATA(travels).

    " 2. Loop over each affected Travel header and read all its existing Bookings
    LOOP AT travels INTO DATA(travel).
      READ ENTITIES OF zr_rap_travel IN LOCAL MODE
        ENTITY Travel BY \_Booking
          FIELDS ( BookingID )
          WITH VALUE #( ( %tky = travel-%tky ) )
        RESULT DATA(bookings).

      " Find highest existing BookingID in this Travel
      max_bookingid = '0000'.
      LOOP AT bookings INTO DATA(booking).
        IF booking-BookingID > max_bookingid.
          max_bookingid = booking-BookingID.
        ENDIF.
      ENDLOOP.

      " Assign sequential BookingIDs to new bookings that don't have one yet
      LOOP AT bookings INTO booking WHERE BookingID IS INITIAL.
        max_bookingid += 1.
        APPEND VALUE #( %tky      = booking-%tky
                        BookingID = max_bookingid ) TO bookings_update.
      ENDLOOP.
    ENDLOOP.

    " 3. Write the new BookingIDs back to the buffer
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Booking
        UPDATE FIELDS ( BookingID )
        WITH bookings_update.
  ENDMETHOD.

  METHOD calculateTotalPrice.
    " 1. Read the parent Travel keys for the modified Bookings
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Booking BY \_Travel
        FIELDS ( TravelUUID )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    " 2. Trigger reCalcTotalPrice on those parent Travel headers
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        EXECUTE reCalcTotalPrice
        FROM CORRESPONDING #( lt_travels ).
  ENDMETHOD.



    METHOD validateCurrencyCode.
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Booking
        FIELDS ( FlightPrice CurrencyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_bookings).

    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Booking BY \_Travel
        FIELDS ( TravelUUID )
        WITH CORRESPONDING #( lt_bookings )
      LINK DATA(lt_travel_links).

    LOOP AT lt_bookings INTO DATA(ls_booking).
      DATA(ls_travel_tky) = lt_travel_links[ KEY id source-%tky = ls_booking-%tky ]-target-%tky.

      APPEND VALUE #( %tky            = ls_booking-%tky
                      %state_area     = 'VALIDATE_CURRENCY'
                      %path-travel-%tky = ls_travel_tky ) TO reported-booking.

      IF ls_booking-FlightPrice IS NOT INITIAL AND ls_booking-CurrencyCode IS INITIAL.
        APPEND VALUE #( %tky = ls_booking-%tky ) TO failed-booking.

        APPEND VALUE #( %tky                  = ls_booking-%tky
                        %state_area           = 'VALIDATE_CURRENCY'
                        %path-travel-%tky     = ls_travel_tky
                        %msg                  = new_message_with_text(
                                                  severity = if_abap_behv_message=>severity-error
                                                  text     = 'Currency code is required when a flight price is entered.' )
                        %element-CurrencyCode = if_abap_behv=>mk-on ) TO reported-booking.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


ENDCLASS.

CLASS lhc_Travel DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Travel RESULT result.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR travel RESULT result.
    METHODS setinitialvalues FOR DETERMINE ON MODIFY
      IMPORTING keys FOR travel~setinitialvalues.
    METHODS validatedates FOR VALIDATE ON SAVE
      IMPORTING keys FOR travel~validatedates.
    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR travel RESULT result.

    METHODS accepttravel FOR MODIFY
      IMPORTING keys FOR ACTION travel~accepttravel RESULT result.

    METHODS rejecttravel FOR MODIFY
      IMPORTING keys FOR ACTION travel~rejecttravel RESULT result.
    METHODS recalctotalprice FOR MODIFY
      IMPORTING keys FOR ACTION travel~recalctotalprice.

    METHODS calculatetotalprice FOR DETERMINE ON MODIFY
      IMPORTING keys FOR travel~calculatetotalprice.
    METHODS validatecurrencycode FOR VALIDATE ON SAVE
      IMPORTING keys FOR travel~validatecurrencycode.

ENDCLASS.

CLASS lhc_Travel IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD setInitialValues.

    " 1. Read the newly created Travel instances from the transactional buffer
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        FIELDS ( TravelID OverallStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    " Remove records that already have a TravelID
    DELETE lt_travels WHERE TravelID IS NOT INITIAL.
    IF lt_travels IS INITIAL.
      RETURN.
    ENDIF.

    " 2. Determine the highest existing TravelID from active and draft tables
    SELECT SINGLE FROM zrap_travel FIELDS MAX( travel_id ) INTO @DATA(lv_max_travelid).
    SELECT SINGLE FROM zrap_d_travel FIELDS MAX( travelid ) INTO @DATA(lv_max_draft_id).
    IF lv_max_draft_id > lv_max_travelid.
      lv_max_travelid = lv_max_draft_id.
    ENDIF.

    " 3. Update the buffer using EML MODIFY ENTITIES
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        UPDATE FIELDS ( TravelID OverallStatus )
        WITH VALUE #( FOR ls_travel IN lt_travels INDEX INTO lv_index (
                        %tky          = ls_travel-%tky
                        TravelID      = lv_max_travelid + lv_index
                        OverallStatus = 'O' " Open
                      ) ).

  ENDMETHOD.

    METHOD validateDates.
    " 1. Read BeginDate and EndDate from the transactional buffer
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        FIELDS ( TravelID BeginDate EndDate )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    LOOP AT lt_travels INTO DATA(ls_travel).
      " Clear any previous state messages for this draft instance
      APPEND VALUE #( %tky        = ls_travel-%tky
                      %state_area = 'VALIDATE_DATES' ) TO reported-travel.

      " Check 1: EndDate must not be before BeginDate
      IF ls_travel-EndDate < ls_travel-BeginDate.
        APPEND VALUE #( %tky = ls_travel-%tky ) TO failed-travel.

        APPEND VALUE #( %tky               = ls_travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                        %msg               = new_message_with_text(
                                               severity = if_abap_behv_message=>severity-error
                                               text     = |End date ({ ls_travel-EndDate DATE = USER }) must be on or after begin date ({ ls_travel-BeginDate DATE = USER }).| )
                        %element-BeginDate = if_abap_behv=>mk-on
                        %element-EndDate   = if_abap_behv=>mk-on ) TO reported-travel.

      " Check 2: BeginDate must not be in the past
      ELSEIF ls_travel-BeginDate < cl_abap_context_info=>get_system_date( ).
        APPEND VALUE #( %tky = ls_travel-%tky ) TO failed-travel.

        APPEND VALUE #( %tky               = ls_travel-%tky
                        %state_area        = 'VALIDATE_DATES'
                        %msg               = new_message_with_text(
                                               severity = if_abap_behv_message=>severity-error
                                               text     = |Begin date ({ ls_travel-BeginDate DATE = USER }) must not be in the past.| )
                        %element-BeginDate = if_abap_behv=>mk-on ) TO reported-travel.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


    METHOD acceptTravel.
    " 1. Update OverallStatus to 'A' (Accepted) in the transactional buffer
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        UPDATE FIELDS ( OverallStatus )
        WITH VALUE #( FOR key IN keys (
                        %tky          = key-%tky
                        OverallStatus = 'A'
                      ) ).

    " 2. Read the updated records back so we can return them in RESULT
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    result = VALUE #( FOR ls_travel IN lt_travels (
                        %tky   = ls_travel-%tky
                        %param = ls_travel
                      ) ).
  ENDMETHOD.

  METHOD rejectTravel.
    " 1. Update OverallStatus to 'X' (Rejected / Canceled) in the transactional buffer
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        UPDATE FIELDS ( OverallStatus )
        WITH VALUE #( FOR key IN keys (
                        %tky          = key-%tky
                        OverallStatus = 'X'
                      ) ).

    " 2. Read the updated records back so we can return them in RESULT
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    result = VALUE #( FOR ls_travel IN lt_travels (
                        %tky   = ls_travel-%tky
                        %param = ls_travel
                      ) ).
  ENDMETHOD.

  METHOD get_instance_features.
    " Read current OverallStatus to enable/disable buttons dynamically
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        FIELDS ( OverallStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    result = VALUE #( FOR ls_travel IN lt_travels (
      %tky                 = ls_travel-%tky
      %action-acceptTravel = COND #( WHEN ls_travel-OverallStatus = 'A'
                                     THEN if_abap_behv=>fc-o-disabled
                                     ELSE if_abap_behv=>fc-o-enabled )
      %action-rejectTravel = COND #( WHEN ls_travel-OverallStatus = 'X'
                                     THEN if_abap_behv=>fc-o-disabled
                                     ELSE if_abap_behv=>fc-o-enabled )
    ) ).
  ENDMETHOD.


  METHOD reCalcTotalPrice.
    TYPES: BEGIN OF ty_amount_per_currency,
             amount        TYPE /dmo/total_price,
             currency_code TYPE /dmo/currency_code,
           END OF ty_amount_per_currency.

    DATA lt_amounts_per_currency TYPE STANDARD TABLE OF ty_amount_per_currency.

    " 1. Read the affected Travel headers
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        FIELDS ( BookingFee CurrencyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    DELETE lt_travels WHERE CurrencyCode IS INITIAL.

    " 2. Read all child Bookings for those Travels
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel BY \_Booking
        FIELDS ( FlightPrice CurrencyCode )
        WITH CORRESPONDING #( lt_travels )
      RESULT DATA(lt_bookings)
      LINK DATA(lt_booking_links).

    LOOP AT lt_travels ASSIGNING FIELD-SYMBOL(<ls_travel>).
      " Start with the Travel's own BookingFee
      lt_amounts_per_currency = VALUE #( ( amount        = <ls_travel>-BookingFee
                                           currency_code = <ls_travel>-CurrencyCode ) ).

      " Collect all Booking FlightPrices belonging to this Travel
      LOOP AT lt_booking_links INTO DATA(ls_link) USING KEY id WHERE source-%tky = <ls_travel>-%tky.
        DATA(ls_booking) = lt_bookings[ KEY id %tky = ls_link-target-%tky ].
        IF ls_booking-CurrencyCode IS NOT INITIAL.
          COLLECT VALUE ty_amount_per_currency(
            amount        = ls_booking-FlightPrice
            currency_code = ls_booking-CurrencyCode ) INTO lt_amounts_per_currency.
        ENDIF.
      ENDLOOP.

      CLEAR <ls_travel>-TotalPrice.

      " Convert foreign currencies into the Travel header currency
      LOOP AT lt_amounts_per_currency INTO DATA(ls_amount).
        IF ls_amount-currency_code = <ls_travel>-CurrencyCode.
          <ls_travel>-TotalPrice += ls_amount-amount.
        ELSE.
          /dmo/cl_flight_amdp=>convert_currency(
            EXPORTING
              iv_amount               = ls_amount-amount
              iv_currency_code_source = ls_amount-currency_code
              iv_currency_code_target = <ls_travel>-CurrencyCode
              iv_exchange_rate_date   = cl_abap_context_info=>get_system_date( )
            IMPORTING
              ev_amount               = DATA(lv_converted_price) ).
          <ls_travel>-TotalPrice += lv_converted_price.
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    " 3. Write the calculated TotalPrice back to the buffer
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        UPDATE FIELDS ( TotalPrice )
        WITH CORRESPONDING #( lt_travels ).
  ENDMETHOD.

  METHOD calculateTotalPrice.
    " Trigger our internal action reCalcTotalPrice
    MODIFY ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        EXECUTE reCalcTotalPrice
        FROM CORRESPONDING #( keys ).
  ENDMETHOD.


  METHOD validateCurrencyCode.
    READ ENTITIES OF zr_rap_travel IN LOCAL MODE
      ENTITY Travel
        FIELDS ( BookingFee CurrencyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_travels).

    LOOP AT lt_travels INTO DATA(ls_travel).
      APPEND VALUE #( %tky        = ls_travel-%tky
                      %state_area = 'VALIDATE_CURRENCY' ) TO reported-travel.

      IF ls_travel-BookingFee IS NOT INITIAL AND ls_travel-CurrencyCode IS INITIAL.
        APPEND VALUE #( %tky = ls_travel-%tky ) TO failed-travel.

        APPEND VALUE #( %tky                  = ls_travel-%tky
                        %state_area           = 'VALIDATE_CURRENCY'
                        %msg                  = new_message_with_text(
                                                  severity = if_abap_behv_message=>severity-error
                                                  text     = 'Currency code is required when a booking fee is entered.' )
                        %element-CurrencyCode = if_abap_behv=>mk-on ) TO reported-travel.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


ENDCLASS.
