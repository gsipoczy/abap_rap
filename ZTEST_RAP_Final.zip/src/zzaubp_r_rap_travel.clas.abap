class ZZAUBP_R_RAP_TRAVEL definition
  public
  abstract
  final
  for behavior of ZZAUR_RAP_TRAVEL .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZZAUBP_R_RAP_TRAVEL IMPLEMENTATION.
ENDCLASS.
